import { useAuth0 } from '@auth0/auth0-react';
import { Cancel } from './components/CheckoutResult/Cancel';
import { Success } from './components/CheckoutResult/Success';
import Footer from './components/Footer';
import { createTheme, Loader, MantineProvider } from '@mantine/core';
import { Notifications } from '@mantine/notifications';
import React, { lazy, useEffect } from 'react';
import { Toaster } from 'react-hot-toast';
import { Navigate, Route, Routes, useLocation } from 'react-router-dom';
import { pageView } from './utils/analytics';
import ErrorBoundary from './components/ErrorBoundary/ErrorBoundary';
import CustomLoader from './components/Loader/Loader';
import MobileWarning from './components/MobileWarning/MobileWarning';

// Import the AuthCallback component
const AuthCallback = lazy(() => import('./components/Auth/AuthCallback'));

// Don't load the big 3D page right away - wait until we need it
const ConfiguratorPage = lazy(() => 
  import('./components/ConfiguratorPage').then(module => ({
    default: module.default
  }))
);

const SupplierConfigurator = lazy(() => 
  import('./components/ConfiguratorPage/variants/SupplierConfigurator/SupplierConfigurator').then(module => ({
    default: module.default
  }))
);

// Import the BetaPage component
const BetaPage = lazy(() => 
  import('./components/BetaPage/BetaPage').then(module => ({
    default: module.default
  }))
);

const VulzConfigurator = lazy(() => 
  import('./components/ConfiguratorPage/variants/VulzConfigurator/VulzConfigurator').then(module => ({
    default: module.default
  }))
);

const StepThruConfigurator = lazy(() => 
  import('./components/ConfiguratorPage/variants/StepThruConfigurator/StepThruConfigurator')
);

const UrbanConfigurator = lazy(() => 
  import('./components/ConfiguratorPage/variants/UrbanConfigurator/UrbanConfigurator')
);

const BookshelfConfigurator = lazy(() => 
  import('./components/ConfiguratorPage/variants/BookshelfConfigurator/BookshelfConfigurator')
);

const SofaConfigurator = lazy(() => 
  import('./components/ConfiguratorPage/variants/SofaConfigurator/SofaConfigurator')
);

const TableConfigurator = lazy(() => 
  import('./components/ConfiguratorPage/variants/TableConfigurator/TableConfigurator')
);

const AppContent: React.FC = () => {
  const location = useLocation();
  const isMobile = window.innerWidth <= 768;
  const isConfiguratorRoute = location.pathname === '/' || 
                             location.pathname.includes('/configurator') ||
                             location.pathname.includes('/vulz') ||
                             location.pathname.includes('/stepthru') ||
                             location.pathname.includes('/urban') ||
                             location.pathname.includes('/bookshelf') ||
                             location.pathname.includes('/sofa') ||
                             location.pathname.includes('/table');

  const { isAuthenticated } = useAuth0();

  useEffect(() => {
    pageView(location.pathname + location.search);
  }, [location]);

  if (isMobile && isConfiguratorRoute) {
    return <MobileWarning />;
  }

  return (
    <div className="app">
      <main className="main-content">
        <Routes>
          {/* Default route - goes straight to configurator */}
          <Route 
            path="/" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <ConfiguratorPage isAuthenticated={isAuthenticated} />
              </React.Suspense>
            } 
          />
          
          {/* Other routes */}
          <Route 
            path="/configurator" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <ConfiguratorPage isAuthenticated={isAuthenticated} />
              </React.Suspense>
            } 
          />
          <Route 
            path="/supplier" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <SupplierConfigurator isAuthenticated={isAuthenticated} />
              </React.Suspense>
            } 
          />
          <Route 
            path="/beta" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <BetaPage />
              </React.Suspense>
            } 
          />
          <Route 
            path="/vulz" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <VulzConfigurator isAuthenticated={isAuthenticated} />
              </React.Suspense>
            } 
          />
          <Route 
            path="/vulz/stepthru" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <StepThruConfigurator isAuthenticated={isAuthenticated} />
              </React.Suspense>
            } 
          />
          <Route 
            path="/vulz/urban" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <UrbanConfigurator isAuthenticated={isAuthenticated} />
              </React.Suspense>
            } 
          />
          <Route 
            path="/bookshelf" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <BookshelfConfigurator isAuthenticated={isAuthenticated} />
              </React.Suspense>
            } 
          />
          <Route 
            path="/sofa" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <SofaConfigurator isAuthenticated={isAuthenticated} />
              </React.Suspense>
            } 
          />
          <Route 
            path="/table" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <TableConfigurator isAuthenticated={isAuthenticated} />
              </React.Suspense>
            } 
          />
          <Route 
            path="/success" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <Success />
              </React.Suspense>
            } 
          />
          <Route 
            path="/cancel" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <Cancel />
              </React.Suspense>
            } 
          />
          <Route 
            path="/callback" 
            element={
              <React.Suspense fallback={<div className="loading-placeholder" />}>
                <AuthCallback />
              </React.Suspense>
            } 
          />         
          <Route path="*" element={<Navigate to="/" />} />
        </Routes>
      </main>
      <Footer />
    </div>
  );
};

const App: React.FC = () => {
  const theme = createTheme({
    components: {
      Loader: {
        defaultProps: {
          loaders: { ...Loader.defaultLoaders, custom: CustomLoader },
          type: 'custom',
        },
      },
    },
  });
  
  return (
    <ErrorBoundary>
      <MantineProvider theme={theme}>
        <Notifications />
        <Toaster position="top-right" />
        <AppContent />
      </MantineProvider>
    </ErrorBoundary>
  );
};

export default App; 