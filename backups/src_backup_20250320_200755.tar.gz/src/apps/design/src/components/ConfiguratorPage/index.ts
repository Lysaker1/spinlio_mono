export { default } from './ConfiguratorPage';
