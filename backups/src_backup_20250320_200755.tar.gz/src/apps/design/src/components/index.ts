export { default as App } from './App';
export { default as ConfiguratorPage } from './ConfiguratorPage';